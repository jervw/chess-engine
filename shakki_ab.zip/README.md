# Chess engine
#----Translated terms----
#Kayttoliittyma = UserInterface
#Move = Move
#Tile = Tile
#State = State
#Lauta = Board
#moveList = moveList

#color = color
#koodi = code

#nappula = pawn